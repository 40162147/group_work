﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trigger : MonoBehaviour 
{
    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.tag == "Player")
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
            GameObject.Find("Text").GetComponent<Ending>().EndStart();

        }
        else
        {

        }

    }

    void OnTriggerExit2D()
    {



    }



}
