﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Ending : MonoBehaviour 
{
    Text text_bit;


    public void Start()
    {
        text_bit = GetComponent<Text>();
    }

    public void EndStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("End");
    }

    IEnumerator End()
    {
        //Spaces need additional stuff

        yield return new WaitForSeconds(1);
        text_bit.text = "Lucy!?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Dracula!";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Just sit tight, everything will be all right.  Jekyll, you mind telling me what's going on?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Dracula … I'm sorry. But you know as well as I do that the other guy has much more power than me-";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Jekyll, you're the one in control here, not him.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "He's there now, speaking to me, whispering things…";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Jekyll … what did he do?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "I'm … I'm sorry Dracula …";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);




        text_bit.text = "Hyde…";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Sup, red-eyes, hows things?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "You-";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Stop, don't answer that, I already know. Tell me, what exactly is it that is so important about this.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        //endings diverge here



        //Bad and evil ending
        if (ApplicationModel.ending > 0)
        {
            yield return new WaitForSeconds(1);
            text_bit.text = "How did you get that amulet.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "There's many things you're none the wiser to, I'm afraid. One being myself, and one more very specific thing which just so happens to be in this very roo-";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Don't listen to him, Drac. He's trying to sway you.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }


            //Bad ending
            if(ApplicationModel.ending == 1)
            {
                yield return new WaitForSeconds(1);
                text_bit.text = "Could be, but then again, I might not be. Come see for yourself.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "I've beat you to the ground before, I'm more than happy to do it again.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }



                yield return new WaitForSeconds(1);
                text_bit.text = "Unfortunatly, that won't be happening.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "What are you doing here?";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "What indeed?";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Just run, Drac, don't worry about me.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Oh, come on. Come get some, red-eyes";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Seems like you're needed after all, Grim.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Sadly, it is not for the reason you think.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Is that so!?";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "What are you saying.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "I've waited a long time for this moment, my immortal friend.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "DRACULA RUN!!";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Vladimir Dracula … your time has come.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
            }

            //Evil ending
            else
            {
                yield return new WaitForSeconds(1);
                text_bit.text = "Oh-ho this is priceless. I'm at my end in this thing now anyway, I'm going to die either way.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "You're not making sense, Hyde.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "But I am, Dracula. You have no idea about things in front-";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Hyde! Drac, he's luring you.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Is that so?";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "You know what? Screw it, I'm dying anyway. Here's your amul-";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Lucy … what's goin-";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Stupid little thing, honestly thought I had him under control. Evidently not.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Lucy...?";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Oh, right, sorry. It seems I've got something to tell you, Dracula.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Luc-";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Firstly, my name's not Lucy.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }



                yield return new WaitForSeconds(1);
                text_bit.text = "It's Lucifer.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "W-what?";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Took me a long time to figure out how to befriend you … all to get this amulet and you in the same room.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }



                yield return new WaitForSeconds(1);
                text_bit.text = "Something of which I was curious about, also.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Good to see you, Grim. How's things?";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Better, now that a long awaited departing is imminent.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Departing?";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "It's yours, by the way.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Why…?";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Because, your immortality has a much better use than just keeping you alive. It can also allow me to bring back those who Grim there has taken.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "A necessary purpose, given its limitations. However, immortality will not convince the departed to return…";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Oh, I think it might just be able to. Tell me, Grim, does it not bother you that I'm going to create more immortals?";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "It does not. Immortality is a faux lie, a shroud used to cover the real name of it:  longevity.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Is that right...";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "No one escapes the end of their story, I'm afraid. That last paragraph, that last sentence, that full stop … it comes to all.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Tell you what, after I'm done with him, we'll test your belief.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "You're not getting me without a figh-";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "Oh, I don't need to fight you. It's already done.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
                yield return new WaitForSeconds(1);
                text_bit.text = "By way of me, I'm afraid. Goodbye, my immortal friend.";
                while (!Input.GetKey("e"))
                {
                    yield return null;
                }
            }
        }
        else
        {
            //Good ending
            yield return new WaitForSeconds(1);
            text_bit.text = "My amulet.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "I'm told wonderful things are contained in this. But here comes the kicker… This, or Lucy.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "What?";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "I'll spell it out … you open this for me, and I'll spare this girl. You try and take the amulet, I'll end the girl. Your choice.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Hyde…";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Hyde stop this.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Figures you two would show up.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Hyde, you don't want to do this. You know what is about to happen-";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "NO! I've spent too long trying to plan this out! Too many people got close to finding this out before the time was right and I had to dispose of them.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "To hide all this, you've gone to those length?";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Yup … even accidentally created a new super while trying to keep it a secret.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "A new super…";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "No...";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "It was you. You pushed Margo onto the tracks.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Well done Sherlock. Now, the choice, Dracula … make it.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "It's not going to happen.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "And why is that?";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Because I am here…";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "No … not you.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "It seems my appointment is due, and the hour is late on your life, young Hyde.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "You can't kill me-";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Come now, you think that I, death itself, cannot end you? Me, who ends countless during wars and entire planets and stars?";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "I can't go now.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Your clock says otherwise…";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Apologies for the intrusion…";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Your appointment was never for Lucy, was it?";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Lucy? Ah, this one … she has escaped my attention more times than I care to mention.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Well, you've done it now. Please go…";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Does my presence alarm you? Does my being the person to end all, scare you, young archangel?";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Can't imagine anyone would be chill while in the presence of death.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
            text_bit.text = "Pity, some people welcome me … at any rate, I must be gone. I will see you all again at some point.";
            while (!Input.GetKey("e"))
            {
                yield return null;
            }
            yield return new WaitForSeconds(1);
        }
    }


}
