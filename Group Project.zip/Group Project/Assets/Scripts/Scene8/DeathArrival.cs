﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathArrival : MonoBehaviour 
{
    GameObject Dtarget;
    public float speed = 20.0f;

    public void Arrival()
    {
        Dtarget = GameObject.Find("DTarget");
    }

    public void Away()
    {
        Dtarget = GameObject.Find("Target");
    }

	
	// Update is called once per frame
	void Update () 
    {
        float step = speed * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, Dtarget.transform.position, step);
	}
}
