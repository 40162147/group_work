﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Train : MonoBehaviour 
{
    GameObject target;
    AudioSource audio;
    public float speed = 200.0f;

    void Start()
    {
        audio = GetComponent<AudioSource>();
        target = GameObject.Find("Target2");
    }

    public void Arrival()
    {
        target = GameObject.Find("Target");
        audio.Play();
    }
    public void Away()
    {
        target = GameObject.Find("Target1");
        audio.Play();
    }
    public void TRAIN()
    {
        target = GameObject.Find("player");
        audio.Play();
    }

    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.tag == "Player")
        {

            GameObject.Find("Text").GetComponent<Ending>().Over();
            
        }
        else
        {

        }

    }
    void OnTriggerExit2D()
    {



    }

    void Update()
    {
        float step = speed * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, target.transform.position, step);
    }
}
