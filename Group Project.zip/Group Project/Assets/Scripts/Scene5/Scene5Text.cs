﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scene5Text : MonoBehaviour {

    Text text_bit;
    GameObject back;
    GameObject hosp;
    GameObject bar;

    void OnLevelWasLoaded()
    {
        back = GameObject.Find("BackButton");
        back.SetActive(false);
        hosp = GameObject.Find("HospitalButton");
        hosp.SetActive(false);
        bar = GameObject.Find("BarButton");
        bar.SetActive(false);
    }

    public void Start()
    {
        text_bit = GetComponent<Text>();
    }

    public void TurnOffButtons()
    {
        back.SetActive(false);
        hosp.SetActive(false);
        bar.SetActive(false);
    }

    public void TalkedToEveryone()
    {
        back.SetActive(true);
        hosp.SetActive(true);
        bar.SetActive(true);
        text_bit.text = "Select Where you want to go";
    }

    public void NotTalkedToEveryone()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("NotYet");
    }

    public void GhostStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Ghost");
    }

    IEnumerator Ghost()
    {

        yield return new WaitForSeconds(1);
        text_bit.text = "Hey, Margo….";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Why can't they see me?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Say again?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "My friends … they can't see me. But you can?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Margo, I can see you because I'm a super, just like you. They can't because they're normal.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Sometimes I'd just like to say hello again. Just once … or to say goodbye.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "How have you been?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "I keep getting flashbacks.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "The subway?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Yeah … lights from the train, the screeching wheels. I can't get them to go away.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "You know there's a whole lot of people out there that could help you with this. There's a place called the Andowald Hotel-";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Yeah I've heard of it. Fen and Jack are there, right?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "And Angie. They're all wanting to help.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "What about that Lucy girl?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "About that, where exactly did you see us both?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "You don't remember? You both helped me at the hospital when I died.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "The hospital. Probably need to speak to Phoebe while I'm there. Margo, go to the Andowald, speak to Angie. She'll help with all this.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "I … I will.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);

        text_bit.text = "";

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator NotYet()
    {
        yield return new WaitForSeconds(1);
        text_bit.text = "Should probably talk with everyone first.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);


        text_bit.text = "";

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }
}
