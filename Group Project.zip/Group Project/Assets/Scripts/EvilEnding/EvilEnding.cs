﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class EvilEnding : MonoBehaviour
{
    Text text_bit;

    void Start()
    {
        text_bit = GetComponent<Text>();
        StartCoroutine("End");
    }

    IEnumerator End()
    {
        yield return new WaitForSeconds(3);
        text_bit.text = "The Andowald Hotel does, indeed, cater to all. And it most definitely seems that with immortality about to be distributed by way of Lucifer, ";
        yield return new WaitForSeconds(3);
        text_bit.text = "the hotel will see many supernatural beings calling its rooms home for the foreseeable future…";
        yield return new WaitForSeconds(3);
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(12);

    }
}
