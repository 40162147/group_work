﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scene4Text : MonoBehaviour {

    Text text_bit;
    GameObject back;
    GameObject morg;
    GameObject bar;
    Image image_bit;
    public Sprite drac;
    public Sprite white;
    public Sprite frank;

    void OnLevelWasLoaded()
    {
        back = GameObject.Find("BackButton1");
        back.SetActive(false);
        morg = GameObject.Find("MorgueButton");
        morg.SetActive(false);
        bar = GameObject.Find("BarButton");
        bar.SetActive(false);
    }

    public void Start()
    {
        text_bit = GetComponent<Text>();
        image_bit = GameObject.Find("Image1").GetComponent<Image>();
        image_bit.sprite = white;
    }

    public void TurnOffButtons()
    {
        back.SetActive(false);
        morg.SetActive(false);
        bar.SetActive(false);
    }

    public void TalkedToEveryone()
    {
        back.SetActive(true);
        morg.SetActive(true);
        bar.SetActive(true);
        text_bit.text = "Select Where you want to go";
    }

    public void NotTalkedToEveryone()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("NotYet");
    }

    public void FrankStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Frank");
    }

    IEnumerator Frank()
    {


        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Frankie.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = frank;
        text_bit.text = "Fangs … how's things?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Honestly? Could be better.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = frank;
        text_bit.text = "Your amulet not being round your neck a reason for that?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Amongst other things … Irene told me I came through here last night with a girl named Lucy.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = frank;
        text_bit.text = "That girl knows too much for her own good.  Sings a lullaby and boom, all your secrets are hers. Yeah I seen you both.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "And?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = frank;
        text_bit.text = "You both waltzed in here laughing with each other and ordered half the menu, I didn't even realise you could actually eat normal food.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "There's a lot of things I can do, Frankie. But we were happy, yeah?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = frank;
        text_bit.text = "Dracula, buddy, friend, I've been thrown together faster than some value brand furniture, but even I can tell when someone's having a genuinely good time.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Give yourself some credit, you punched me through a wall at one point-";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = frank;
        text_bit.text = "Heh, yeah! Those were the times, Fangs. Word couldn't spread everywhere in seconds, ship rides between countries would take days, none of this fast food working crap.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "You know you could work at the Andowald, right? They're hiring straight outta the super community.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = frank;
        text_bit.text = "I don't get along well with other supers, Fangs, you know that.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "They're in the same boat as you.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = frank;
        text_bit.text = "Tell that to Margo…";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "How is she doing, by the way?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = frank;
        text_bit.text = "She hangs around the restaurant, pay her a visit. Jekyll said you went by her grave as well.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Me?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = frank;
        text_bit.text = "You and that Lucy girl.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Right … I'll go speak to Jekyll and see what's, what.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);

        text_bit.text = "";
        image_bit.sprite = white;
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator NotYet()
    {
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Should probably talk with everyone first.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);

        image_bit.sprite = white;
        text_bit.text = "";

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }
}
