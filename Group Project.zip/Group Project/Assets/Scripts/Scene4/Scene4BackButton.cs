﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene4BackButton : MonoBehaviour 
{

    public void Back()
    {
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
        GameObject.Find("Text").GetComponent<Scene4Text>().TurnOffButtons();
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
    }

}
