﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene4Door : MonoBehaviour {

    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.tag == "Player" && Input.GetKey("e") && (GameObject.Find("Frank North").GetComponent<Frank>().Talked == true) || ApplicationModel.fastfood > 1)
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
            GameObject.Find("player").GetComponent<Walking>().WalkingNorth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingSouth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingWest = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingEast = false;
            GameObject.Find("player").GetComponent<AudioSource>().Stop();
            GameObject.Find("Text").GetComponent<Scene4Text>().TalkedToEveryone();

        }
        else if (other.gameObject.tag == "Player" && Input.GetKey("e") && GameObject.Find("Frank North").GetComponent<Frank>().Talked == false)
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingNorth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingSouth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingWest = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingEast = false;
            GameObject.Find("player").GetComponent<AudioSource>().Stop();
            GameObject.Find("Text").GetComponent<Scene4Text>().NotTalkedToEveryone();

        }
        else
        {

        }

    }

    void OnTriggerExit2D()
    {



    }
}
