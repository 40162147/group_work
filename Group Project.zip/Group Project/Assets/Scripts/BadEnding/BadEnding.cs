﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BadEnding : MonoBehaviour 
{

    Text text_bit;

    void Start()
    {
        text_bit = GetComponent<Text>();
        StartCoroutine("End");
    }

    IEnumerator End()
    {
        yield return new WaitForSeconds(2);
        text_bit.text = "With Dracula gone, the state of play has become unbalanced. Hyde is indeed the culprit,  ";
        yield return new WaitForSeconds(3);
        text_bit.text = "but Jekyll stands in the way of punishment. Immortality now sits in the palm of Hyde.";
        yield return new WaitForSeconds(3);
        text_bit.text = "But to what end …..";
        yield return new WaitForSeconds(3);
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(12);

    }

}
