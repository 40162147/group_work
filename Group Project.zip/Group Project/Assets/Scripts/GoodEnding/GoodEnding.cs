﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GoodEnding : MonoBehaviour 
{
    GameObject lucy;
    GameObject devil;
    Text text_bit;
	
	void Start () 
    {
        text_bit = GetComponent<Text>();
        devil = GameObject.Find("Lucifer East");
        devil.SetActive(false);
        lucy = GameObject.Find("Lucy East");
		StartCoroutine("End");
	}

    IEnumerator End()
    {

        yield return new WaitForSeconds(3);
        text_bit.text = "Andowald does indeed cater to all known supernatural beings, be they odd, weird, big, small.";
        yield return new WaitForSeconds(3);
        text_bit.text = "Dracula successfully fended off Hyde, with the help of Death itself.";
        yield return new WaitForSeconds(3);
        text_bit.text = "However, as all good things must be, sometimes, there may be unknown horrors hidden in plain sight.";
        lucy.SetActive(false);
        devil.SetActive(true);
        yield return new WaitForSeconds(3);
        devil.SetActive(false);
        lucy.SetActive(true);
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(12);
    }

}
