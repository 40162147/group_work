﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zombie : MonoBehaviour {

    public bool North = false;
    public bool South = false;
    public bool East = false;
    public bool West = false;
    public bool Talked = false;
    Animator animZombie;

    void Start()
    {
        animZombie = GetComponent<Animator>();
    }

    void Update()
    {
        animZombie.SetBool("PSouth", North);
        animZombie.SetBool("PNorth", South);
        animZombie.SetBool("PWest", East);
        animZombie.SetBool("PEast", West);

    }

    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.tag == "Player" && Input.GetKey("e") && Talked == false && ApplicationModel.bar == 0)
        {
            South = GameObject.Find("player").GetComponent<Walking>().North;
            North = GameObject.Find("player").GetComponent<Walking>().South;
            East = GameObject.Find("player").GetComponent<Walking>().West;
            West = GameObject.Find("player").GetComponent<Walking>().East;
            GameObject.Find("player").GetComponent<Walking>().WalkingNorth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingSouth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingWest = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingEast = false;
            GameObject.Find("player").GetComponent<AudioSource>().Stop();
            Talked = true;
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("Text").GetComponent<Scene2Text>().ZombieStart();

        }
        else
        {

        }

    }
}
