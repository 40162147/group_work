﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene2Door : MonoBehaviour {


    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.tag == "Player" && Input.GetKey("e") && (GameObject.Find("Angela").GetComponent<Angel>().Talked == true && GameObject.Find("werewolf").GetComponent<Wolf>().Talked == true && GameObject.Find("Zombie").GetComponent<Zombie>().Talked == true) || ApplicationModel.bar > 0)
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
            GameObject.Find("player").GetComponent<Walking>().WalkingNorth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingSouth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingWest = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingEast = false;
            GameObject.Find("player").GetComponent<AudioSource>().Stop();
            GameObject.Find("Text").GetComponent<Scene2Text>().TalkedToEveryone();

        }
        else if (other.gameObject.tag == "Player" && Input.GetKey("e") && GameObject.Find("Angela").GetComponent<Angel>().Talked == false || GameObject.Find("Zombie").GetComponent<Zombie>().Talked == false || GameObject.Find("Werewolf").GetComponent<Wolf>().Talked == false)
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingNorth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingSouth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingWest = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingEast = false;
            GameObject.Find("player").GetComponent<AudioSource>().Stop();
            GameObject.Find("Text").GetComponent<Scene2Text>().NotTalkedToEveryone();

        }
        else
        {

        }

    }

    void OnTriggerExit2D()
    {



    }
}
