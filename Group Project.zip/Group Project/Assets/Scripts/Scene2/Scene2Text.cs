﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scene2Text : MonoBehaviour 
{
    Text text_bit;
    GameObject back;
    GameObject coff;
    GameObject rest;
    GameObject fast;

  

    void OnLevelWasLoaded()
    {
        back = GameObject.Find("BackButton1");
        back.SetActive(false);
        coff = GameObject.Find("CoffeeShopButton");
        coff.SetActive(false);
        rest = GameObject.Find("RestrauntButton");
        rest.SetActive(false);
        fast = GameObject.Find("FastFoodButton");
        fast.SetActive(false);
        text_bit = GetComponent<Text>();
    }

    public void BeginStart()
    {
        text_bit = GetComponent<Text>();
        StartCoroutine("Begin");
    }

    public void TurnOffButtons()
    {
        back.SetActive(false);
        coff.SetActive(false);
        rest.SetActive(false);
        fast.SetActive(false);
    }

    public void TalkedToEveryone()
    {
        back.SetActive(true);
        coff.SetActive(true);
        rest.SetActive(true);
        fast.SetActive(true);
        text_bit.text = "Select Where you want to go";
    }

    public void NotTalkedToEveryone()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("NotYet");
    }

    public void AngelStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Angel");
    }

    public void WerewolfStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Werewolf");
    }

    public void ZombieStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Zombie");
    }


    IEnumerator Begin()
    {
        yield return new WaitForSeconds(1);
        text_bit.text = "(She isn't here. It's worse than I thought, I'm sure I was here with her last night … Angela, Fen, or Jack might know what happened.)";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "";
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator Angel()
    {

        yield return new WaitForSeconds(1);
        text_bit.text = "Hey, Angie, how's things?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Dracula? Would've thought you would still be with Lucy.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Heh, well, that's the thing; she wasn't with me when I woke up-";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Your people skills need serious working on if that's the case.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Says the girl following the bible like it's the gospel.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "My point exactly.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "I also … can't actually remember last night, at all, and I'm worried about her.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "She must be special for you to be worried?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "That, and the fact that I've lived nigh on half a millennia and never suffered memory loss once.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Never?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Not at all. And it coincidentally happens to revolve around seeing Lucy, so I'm trying to piece things together.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Well, Irene told me you both went by her coffee shop at some point. ";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Irene's place?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "That's what she told me. Said you and Lucy were having a grand old time.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Thanks, Angie.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);

        text_bit.text = "";

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator Zombie()
    {

        yield return new WaitForSeconds(1);
        text_bit.text = "Let me guess, the girl ain't anywhere in sight?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Hit the nail on the head, Jack. Any idea what happened?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Word is, you said a few sentences to Margo last night at some point.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Margo? Where? Her grave or old work?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Current place, the restaurant. Jekyll didn't say anything about you passing through the morgue to her grave.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "You still talking to Jekyll?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Yeah, what of it?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Well I thought … with everything Hyde did-";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Listen, Dracula, Jekyll had nothing to do with Margo. Hyde, on the other hand, might have. But I can't really do anything about it without hurting Jekyll.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "So you're drowning your sorrows instead.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Hey, I'm already dead … a little whiskey ain't gonna hurt my already decomposing liver.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Sure … but still.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Away and search for your friend, Dracula.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);

        text_bit.text = "";

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator Werewolf()
    {

        yield return new WaitForSeconds(1);
        text_bit.text = "You win anything yet, Fen?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Are you best friends with the pope, mate?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Right. By the way, you don't happen to know what happened with me and the girl I was with last night do you? I can't actually remember anything.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "I'd imagine most nights with woman for you end with a drink of the red stuff, pal?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Fen we we-";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Or any person that happens across you in the night, for that matter.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Come on, Fen, those days are behind me. You'd be big and hairy and after my head if it they weren't.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Too right. Still remember the first time you seen my true self, wiped that grin straight off your face when I threw you through that stained glass window in Paris.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "We were young then, barley 100. Anyway, the girl I was with?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "No idea, Drax. Frankie said you both got a quick bite at Mics, though.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Did he? Right…";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "You're acting stranger than usual, Drax.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "I don't normally forget things-";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Your amulet's not around your neck.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "You spotted that.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Pretty hard not too. Big ugly thing, I'm surprised it doesn't crack glass-";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Watch it, Fen.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Sure. But I'd check with Frankie, I'd bet my blue furred tail that he knows something.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Got it.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);


        text_bit.text = "";

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }


    IEnumerator NotYet()
    {
        yield return new WaitForSeconds(1);
        text_bit.text = "Should probably talk with everyone first.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);


        text_bit.text = "";

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }
}
