﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RestrauntButton : MonoBehaviour {

    IEnumerator FadeToNextLevel()
    {
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(5);

    }



    public void NextScene()
    {
        ApplicationModel.rest = ApplicationModel.rest + 1;
        StartCoroutine("FadeToNextLevel");
    }
}
