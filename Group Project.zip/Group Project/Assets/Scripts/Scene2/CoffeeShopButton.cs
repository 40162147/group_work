﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoffeeShopButton : MonoBehaviour {

    IEnumerator FadeToNextLevel()
    {
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(3);

    }



    public void NextScene()
    {
        ApplicationModel.coffee = ApplicationModel.coffee + 1;
        StartCoroutine("FadeToNextLevel");
    }
}
