﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackButton : MonoBehaviour 
{
    public void Back()
    {
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
        GameObject.Find("Text").GetComponent<Scene2Text>().TurnOffButtons();
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
    }

}
