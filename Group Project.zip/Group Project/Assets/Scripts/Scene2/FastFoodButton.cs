﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FastFoodButton : MonoBehaviour 
{

    IEnumerator FadeToNextLevel()
    {
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(4);

    }



    public void NextScene()
    {
        ApplicationModel.fastfood = ApplicationModel.fastfood + 1;
        StartCoroutine("FadeToNextLevel");
    }
}
