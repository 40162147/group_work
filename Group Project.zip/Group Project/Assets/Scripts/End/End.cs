﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class End : MonoBehaviour {

    Text text_bit;

    void Start()
    {
        text_bit = GetComponent<Text>();
        StartCoroutine("Ender");
    }

    IEnumerator Ender()
    {
        yield return new WaitForSeconds(2);
        text_bit.text = "THE END";
        yield return new WaitForSeconds(5);



    }
}
