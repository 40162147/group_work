﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scene6Text : MonoBehaviour {

    Text text_bit;
    GameObject bird;
    Image image_bit;
    public Sprite drac;
    public Sprite white;
    public Sprite death;
    public Sprite fire;

    public void Start()
    {
        text_bit = GetComponent<Text>();
        bird = GameObject.Find("drPhoebe West");
        bird.SetActive(false);
        image_bit = GameObject.Find("Image1").GetComponent<Image>();
        image_bit.sprite = white;
    }

    public void DeathStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        bird.SetActive(true);
        StartCoroutine("Death");
    }

    public void BirdStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Bird");
    }

    public void TalkedToEveryone()
    {
        StartCoroutine("FadeToNextLevel");
    }

    public void NotTalkedToEveryone()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("NotYet");
    }

    IEnumerator Death()
    {

        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Suppose it's normal to find you here, of all places.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = death;
        text_bit.text = "A hospital is like a terminal to me, young Dracula. A place where life either fizzles out, or moves on.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Is that so?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = death;
        text_bit.text = "I remember our first meeting was in a place not unlike this.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Still not got to me yet, have you.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = death;
        text_bit.text = "It will happen … at some point. Death is inevitable, it comes to all. I'll be there at the end of the universe and all within, I will most certainly be there for your ending chapter.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Duly noted. Just while you're here as well, probably normal in your line of work, but did you see myself and a girl last night by chance?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = death;
        text_bit.text = "The girl with the red hair?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "That's the one!";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = death;
        text_bit.text = "Hmm … I did indeed see her. In fact, I have an appointment at a certain subway soon … and she is going to be present.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Dammit! Bye!";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = death;
        text_bit.text = "Take heed, young Dracula, all is not what it seems…";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);


        text_bit.text = "";
        image_bit.sprite = white;

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator Bird()
    {

        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "What is it, Pheebs, I'm in kinda a hurry.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = fire;
        text_bit.text = "That any way to greet your only legal source of blood?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "I'm sorry but I really am in a hurry.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = fire;
        text_bit.text = "Right, those tests taken last night are back.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Tests?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = fire;
        text_bit.text = "You won't remember. Before you left, you felt odd and asked to be tested quickly by myself for any oddities.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "I can't get infected by any drugs or things like that.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = fire;
        text_bit.text = "Apparently you can … and I've never seen or heard of a toxin with this level of power.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "And I had it in me, how?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = fire;
        text_bit.text = "That's the question … but you were poisoned, make no mistake. That's why you can't remember anything about last night.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Right, thanks for that. Now I really have to go, take care.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);


        text_bit.text = "";
        image_bit.sprite = white;

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator NotYet()
    {
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Should probably talk with everyone first.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);


        text_bit.text = "";
        image_bit.sprite = white;
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator FadeToNextLevel()
    {
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(8);

    }
}
