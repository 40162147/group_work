﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Death : MonoBehaviour {


    public bool South = false;
    public bool East = false;
    public bool North = false;
    public bool West = false;
    public bool Talked = false;

    Animator animDeath;

    void Start()
    {
        animDeath = GetComponent<Animator>();
    }

    void Update()
    {
        animDeath.SetBool("PNorth", South);
        animDeath.SetBool("PWest", East);
        animDeath.SetBool("FaceNorth", North);
        animDeath.SetBool("FaceWest", West);

    }

    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.tag == "Player" && Input.GetKey("e") && Talked == false)
        {
            South = GameObject.Find("player").GetComponent<Walking>().North;
            East = GameObject.Find("player").GetComponent<Walking>().West;
            GameObject.Find("player").GetComponent<Walking>().WalkingNorth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingSouth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingWest = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingEast = false;
            GameObject.Find("player").GetComponent<AudioSource>().Stop();
            Talked = true;
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("Text").GetComponent<Scene6Text>().DeathStart();

        }
        else
        {

        }

    }
}
