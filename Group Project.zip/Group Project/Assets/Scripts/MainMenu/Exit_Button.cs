﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Exit_Button : MonoBehaviour {

    public void Quit ()
    {
        Application.Quit();
    }
}
