﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Intro : MonoBehaviour 
{

	
    Text text_bit;

    void Start()
    {
        text_bit = GetComponent<Text>();
        StartCoroutine("Introer");
    }

    IEnumerator Introer()
    {
        yield return new WaitForSeconds(3);
        text_bit.text = "Ever wonder where those things people would talk about in fairy tales and scary stories came from? ";
        yield return new WaitForSeconds(3);
        text_bit.text = "Those age old tales where monsters exist and round every corner of night, something lays in wait.";
        yield return new WaitForSeconds(3);
        text_bit.text = "Werewolves, vampires, ghouls, ghosts; they are all very real. And they live and survive in the world alongside everyone else.";
        yield return new WaitForSeconds(3);
        text_bit.text = "And while mostly shunned and hidden from sight, some places cater to these very specific types of supernaturals, or supers: ";
        yield return new WaitForSeconds(3);
        text_bit.text = "the Andowald Hotel is just one of them.This establishment allows all those who would be classed as supernatural to live and act as normal within, without worry of being found out. ";
        yield return new WaitForSeconds(3);
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(1);
    }
}
