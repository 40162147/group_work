﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarButton : MonoBehaviour {

    IEnumerator FadeToNextLevel()
    {
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(2);

    }



    public void NextScene()
    {
        ApplicationModel.bar = ApplicationModel.bar + 1;
        StartCoroutine("FadeToNextLevel");
    }
}
