﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HospitalButton : MonoBehaviour {

    IEnumerator FadeToNextLevel()
    {
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(6);

    }



    public void NextScene()
    {
        StartCoroutine("FadeToNextLevel");
    }
}
