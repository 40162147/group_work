﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Walking : MonoBehaviour 
{
    public float speed = 0.8f;
    public bool KeysEnabled = true;
    public int CurrentScene = 0;
    public bool North = false;
    public bool South = true;
    public bool East = false;
    public bool West = false;
    public bool WalkingNorth = false;
    public bool WalkingSouth = false;
    public bool WalkingEast = false;
    public bool WalkingWest = false;
    public bool HasKey = false;
    AudioSource audio;
    Animator anim;
    
    void Start ()
    {
        audio = GetComponent<AudioSource>();
        anim = GetComponent<Animator> ();
        GameObject.Find("NoteUI").GetComponent<Image>().enabled = false;
    }
   
    
	void Update () 
    {
        anim.SetBool("North", North);
        anim.SetBool("South", South);
        anim.SetBool("East", East);
        anim.SetBool("West", West);
        anim.SetBool("WalkingNorth", WalkingNorth);
        anim.SetBool("WalkingEast", WalkingEast);
        anim.SetBool("WalkingSouth", WalkingSouth);
        anim.SetBool("WalkingWest", WalkingWest);
        
        if (KeysEnabled == true)
        {
		    if (Input.GetKey("w"))
            {

              
                transform.position += Vector3.up * speed;
                

                WalkingNorth = true;
                WalkingSouth = false;
                WalkingEast = false;
                WalkingWest = false;
                North = true;
                South = false;
                East = false;
                West = false;

                if (!audio.isPlaying)
                {
                    audio.Play();
                }

                
                

    
            }
            else
            {
                WalkingNorth = false;
                WalkingSouth = false;
                WalkingEast = false;
                WalkingWest = false;
                
            }


            if (Input.GetKey("d"))
            {
                transform.position += Vector3.right * speed;

                WalkingEast = true;
                WalkingNorth = false;
                WalkingSouth = false;
                WalkingWest = false;

                North = false;
                South = false;
                East = true;
                West = false;

                if (!audio.isPlaying)
                {
                    audio.Play();
                }

            }



            if (Input.GetKey("s"))
            {
                transform.position += Vector3.down * speed;

                WalkingSouth = true;
                WalkingEast = false;
                WalkingWest = false;
                WalkingNorth = false;

                North = false;
                South = true;
                East = false;
                West = false;


                if (!audio.isPlaying)
                {
                    audio.Play();
                }

                
            }

            if (Input.GetKey("a"))
            {
                transform.position += Vector3.left * speed;

                WalkingWest = true;
                WalkingNorth = false;
                WalkingSouth = false;
                WalkingEast = false;

                North = false;
                South = false;
                East = false;
                West = true;

                if (!audio.isPlaying)
                {
                    audio.Play();
                }

             
            }
            if (!Input.GetKey("a") && !Input.GetKey("s") && !Input.GetKey("d") && !Input.GetKey("w") )
            {
                audio.Stop();
            }
          
  
        }


	}


    void OnLevelWasLoaded()
    {
        CurrentScene = UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex;


        if (CurrentScene == 1)
        {
            KeysEnabled = false;
            GameObject.Find("Text").GetComponent<Scene1Text>().BeginStart();
            
        }
        else if (CurrentScene == 2 && ApplicationModel.bar == 0)
        {
            KeysEnabled = false;
            GameObject.Find("Text").GetComponent<Scene2Text>().BeginStart();

        }
        else
        {
            GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        }
    }

}
