﻿
public class ApplicationModel
{
    static public int bar = 0;
    static public int coffee = 0;
    static public int rest = 0;
    static public int fastfood = 0;
    static public int ending = 0;
}
