﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene1_Door : MonoBehaviour
{

    AudioSource audio;


    void Start()
    {
        audio = GetComponent<AudioSource>();
    }


    void OnTriggerEnter2D(Collider2D other)
    {



        if (other.gameObject.tag == "Player" && Input.GetKey("e") && GameObject.Find("player").GetComponent<Walking>().HasKey == true)
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingNorth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingSouth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingWest = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingEast = false;
            audio.Play();
            GameObject.Find("player").GetComponent<AudioSource>().Stop();
            GameObject.Find("Text").GetComponent<Scene1Text>().DoorUnlockStart();

        }
        else if (other.gameObject.tag == "Player" && Input.GetKey("e") && GameObject.Find("player").GetComponent<Walking>().HasKey == false)
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingNorth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingSouth = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingWest = false;
            GameObject.Find("player").GetComponent<Walking>().WalkingEast = false;
            GameObject.Find("player").GetComponent<AudioSource>().Stop();
            GameObject.Find("Text").GetComponent<Scene1Text>().DoorLockStart();

        }
        else
        {

        }

    }

    void OnTriggerExit2D()
    {



    }



}
