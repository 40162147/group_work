﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene1_Door : MonoBehaviour
{

    void OnTriggerEnter2D(Collider2D other)
    {



        if (other.gameObject.tag == "Player" && Input.GetKey("e") && GameObject.Find("player").GetComponent<Walking>().HasKey == true)
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("Text").GetComponent<Scene1Text>().DoorUnlockStart();

        }
        else if (other.gameObject.tag == "Player" && Input.GetKey("e") && GameObject.Find("player").GetComponent<Walking>().HasKey == false)
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("Text").GetComponent<Scene1Text>().DoorLockStart();

        }
        else
        {

        }

    }

    void OnTriggerExit2D()
    {



    }



}
