﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scene1Text : MonoBehaviour 
{
    Text text_bit;
    Image image_bit;
    public Sprite drac;
    public Sprite white;

    public void BeginStart()
    {
        image_bit = GameObject.Find("Image1").GetComponent<Image>();
        image_bit.sprite = white;
        text_bit = GetComponent<Text>();
        StartCoroutine("Begin");
    }
    public void DoorUnlockStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Unlock");
    }
    public void DoorLockStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Lock");
    }
    public void KeyStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Keys");
    }
    public void PhoneStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Phone");
    }
    public void NoteStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Note");
    }



    IEnumerator Begin()
    {
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "(Huh, different. Never had a hangover before. Headache, thirsty … first time for everything, I guess.)";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "I … can't remember last night, or yesterday. Lucy isn't here as well … My amulet's gone, too! What the hell happened?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "I don't know … I need to find out what happened…";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = white;
        text_bit.text = "";
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }
    IEnumerator Lock()
    {
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "(Its Locked i'll need the key)";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        image_bit.sprite = white;
        text_bit.text = "";
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator Unlock()
    {
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "She'll probably be back down at the bar somewhere.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        image_bit.sprite = white;
        text_bit.text = "";
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(2);
        
    }

    IEnumerator Keys()
    {
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "(Theres my door key)";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        image_bit.sprite = white;
        text_bit.text = "";
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("key").SetActive(false);
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
        GameObject.Find("player").GetComponent<Walking>().HasKey = true;
    }

    IEnumerator Phone()
    {
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "(Theres my Phone)";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        image_bit.sprite = white;
        text_bit.text = "";
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator Note()
    {
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "(A receipt?)";
        GameObject.Find("NoteUI").GetComponent<Image>().enabled = true;
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        yield return new WaitForSeconds(1);
        text_bit.text = "Fredwoods? Must have had a few drinks there together downstairs.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        GameObject.Find("NoteUI").SetActive(false);
        image_bit.sprite = white;
        text_bit.text = "";
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("Note").SetActive(false);
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }
}
