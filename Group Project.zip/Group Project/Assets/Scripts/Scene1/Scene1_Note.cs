﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene1_Note : MonoBehaviour {


    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.tag == "Player" && Input.GetKey("e"))
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("Text").GetComponent<Scene1Text>().NoteStart();

        }
        else
        {

        }

    }
}
