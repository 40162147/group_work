﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene7Door : MonoBehaviour {

    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.tag == "Player" && Input.GetKey("e") && GameObject.Find("jekyll East").GetComponent<Jekyll>().Talked == true)
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
            GameObject.Find("Text").GetComponent<Scene7Text>().TalkedToEveryone();

        }
        else if (other.gameObject.tag == "Player" && Input.GetKey("e") && GameObject.Find("jekyll East").GetComponent<Jekyll>().Talked == false)
        {
            GameObject.Find("player").GetComponent<Walking>().KeysEnabled = false;
            GameObject.Find("Text").GetComponent<Scene7Text>().NotTalkedToEveryone();

        }
        else
        {

        }

    }

    void OnTriggerExit2D()
    {



    }

}
