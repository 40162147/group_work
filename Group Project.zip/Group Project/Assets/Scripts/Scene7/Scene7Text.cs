﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scene7Text : MonoBehaviour 
{

    Text text_bit;


    public void Start()
    {
        text_bit = GetComponent<Text>();
    }

    public void TalkedToEveryone()
    {
        StartCoroutine("FadeToNextLevel");
    }

    public void NotTalkedToEveryone()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("NotYet");
    }

    public void JekyllStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Jekyll");
    }

    IEnumerator Jekyll()
    {

        yield return new WaitForSeconds(1);
        text_bit.text = "Jekyll…";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        yield return new WaitForSeconds(1);
        text_bit.text = "Dracula…";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        yield return new WaitForSeconds(1);
        text_bit.text = "Been a while, hasn't it?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        yield return new WaitForSeconds(1);
        text_bit.text = "In a manner of speaking…";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        yield return new WaitForSeconds(1);
        text_bit.text = "Been told to come here by Frankie.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        yield return new WaitForSeconds(1);
        text_bit.text = "Frankie, yeah?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        yield return new WaitForSeconds(1);
        text_bit.text = "Says you told him I came through here with a girl. I need to know what happened.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        yield return new WaitForSeconds(1);
        text_bit.text = "Did he now.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        yield return new WaitForSeconds(1);
        text_bit.text = "I'm not playing games here, Jekyll. I need to know what happened.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        yield return new WaitForSeconds(1);
        text_bit.text = "Right, right. You both came here, said some words about Margo, then something happened. She started muttering about some subway. The one Margo … passed away in.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }

        yield return new WaitForSeconds(1);
        text_bit.text = "That subway?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "I'm not sure what it meant but that's it.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        text_bit.text = "Right. I'm gonna go check what this all means.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);

        text_bit.text = "";

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator NotYet()
    {
        yield return new WaitForSeconds(1);
        text_bit.text = "Should probably talk with everyone first.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);


        text_bit.text = "";

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }

    IEnumerator FadeToNextLevel()
    {
        float fadeTime = GameObject.Find("Canvas").GetComponent<FadeIn>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        Application.LoadLevel(8);

    }
}
