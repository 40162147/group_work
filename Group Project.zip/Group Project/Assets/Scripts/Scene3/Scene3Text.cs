﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scene3Text : MonoBehaviour 
{
    Text text_bit;
    GameObject back;
    GameObject hosp;
    GameObject bar;
    Image image_bit;
    public Sprite drac;
    public Sprite white;
    public Sprite siren;
 

    void OnLevelWasLoaded()
    {
        back = GameObject.Find("BackButton");
        back.SetActive(false);
        hosp = GameObject.Find("HospitalButton");
        hosp.SetActive(false);
        bar = GameObject.Find("BarButton");
        bar.SetActive(false);

    }

    public void Start()
    {
        text_bit = GetComponent<Text>();
        image_bit = GameObject.Find("Image1").GetComponent<Image>();
        image_bit.sprite = white;
    }

    public void TurnOffButtons()
    {
        back.SetActive(false);
        hosp.SetActive(false);
        bar.SetActive(false);
    }

    public void TalkedToEveryone()
    {
        back.SetActive(true);
        hosp.SetActive(true);
        bar.SetActive(true);
        text_bit.text = "Select Where you want to go";
    }

    public void NotTalkedToEveryone()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("NotYet");
    }



    public void SirenStart()
    {
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        StartCoroutine("Siren");
    }

    IEnumerator Siren()
    {

        yield return new WaitForSeconds(1);
        image_bit.sprite = siren;
        text_bit.text = "I'd appreciate none of your antics in my shop, Drax, I rather like getting customers.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Did Angie not tell you? Phoebe gives me blood bags from the hospital … no harm done.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = siren;
        text_bit.text = "I sometimes take for granted that she's a phoenix and can regenerate fresh donated blood on a whim for you.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Means I can be a functioning member of society.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = siren;
        text_bit.text = "Functioning being the operative word.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "At least I don't sing a lullaby to attract customers when business runs thin.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = siren;
        text_bit.text = "Hey, being a Siren has some benefits.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Right. Anyway, Angie told me that I came through here with a girl named Lucy? You remember where we came from, or where we went, for that matter?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = siren;
        text_bit.text = "Can you not remember?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Not a thing…";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = siren;
        text_bit.text = "Odd. Well Phoebe told me you both spoke some words to Margo in the hospital as she died after you left here.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Is that right?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = siren;
        text_bit.text = "Apparently this Lucy convinced you to try and ease the transition of our newest supernatural. Margo had only words of praise for you both,";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = siren;
        text_bit.text = "seeing as she was still mentally human after turning into a ghost.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "I'll need to drop by the hospital, then. Thanks, Irene.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = siren;
        text_bit.text = "Tell Phoebe I said hello, would you?";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Sure thing.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);

        text_bit.text = "";
        image_bit.sprite = white;
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }


    IEnumerator NotYet()
    {
        yield return new WaitForSeconds(1);
        image_bit.sprite = drac;
        text_bit.text = "Should probably talk with everyone first.";
        while (!Input.GetKey("e"))
        {
            yield return null;
        }
        yield return new WaitForSeconds(1);

        image_bit.sprite = white;
        text_bit.text = "";

        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        GameObject.Find("player").GetComponent<Walking>().KeysEnabled = true;
    }
}
